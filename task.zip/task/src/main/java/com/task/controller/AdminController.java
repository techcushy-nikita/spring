package com.task.controller;

import com.task.entity.UserLocation;
import com.task.repository.UserLocationRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

    @RestController
    @RequestMapping("/admin/user-locations")
    public class AdminController {
        private final UserLocationRepository userLocationRepository;

        @Autowired
        public AdminController(UserLocationRepository userLocationRepository) {
            this.userLocationRepository = userLocationRepository;
        }

        @PostMapping
        public ResponseEntity<UserLocation> createUserLocation(@RequestBody UserLocation userLocation) {
            UserLocation createdLocation = userLocationRepository.save(userLocation);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdLocation);
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteUserLocation(@PathVariable Long id) {
            userLocationRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }

        @PatchMapping("/{id}")
        public ResponseEntity<UserLocation> updatePartialUserLocation(
                @PathVariable Long id,
                @RequestBody Map<String, Object> updates) {
            UserLocation existingLocation = userLocationRepository.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("User Location not found"));



            UserLocation updatedLocation = userLocationRepository.save(existingLocation);
            return ResponseEntity.ok(updatedLocation);
        }

    }