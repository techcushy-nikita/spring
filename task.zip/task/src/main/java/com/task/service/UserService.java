package com.task.service;
import com.task.entity.UserLocation;
import org.springframework.stereotype.Service;

@Service
public interface UserService {
    UserLocation createUserLocation(UserLocation userLocation);
    UserLocation updateUserLocation(Long id, UserLocation updatedUserLocation);
    void deleteUserLocation(Long id);
}
