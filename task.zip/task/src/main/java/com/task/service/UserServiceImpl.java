package com.task.service;

import com.task.repository.UserLocationRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import com.task.entity.UserLocation;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserLocationRepository userLocationRepository;

    @Autowired
    public UserServiceImpl(UserLocationRepository userLocationRepository) {
        this.userLocationRepository = userLocationRepository;
    }

    @Override
    public UserLocation createUserLocation(UserLocation userLocation) {
        return userLocationRepository.save(userLocation);
    }

    @Override
    public UserLocation updateUserLocation(Long id, UserLocation updatedUserLocation) {
        UserLocation existingUserLocation = userLocationRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User Location not found"));

        // Update fields with new values
        existingUserLocation.setName(updatedUserLocation.getName());
        existingUserLocation.setLatitude(updatedUserLocation.getLatitude());
        existingUserLocation.setLongitude(updatedUserLocation.getLongitude());
        existingUserLocation.setExcluded(updatedUserLocation.isExcluded());

        return userLocationRepository.save(existingUserLocation);
    }

    @Override
    public void deleteUserLocation(Long id) {
        userLocationRepository.deleteById(id);
     }
}