package com.task.service;

import com.task.entity.UserLocation;
import com.task.repository.UserLocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class ReaderService {
    private final UserLocationRepository userLocationRepository;

    @Autowired
    public ReaderService(UserLocationRepository userLocationRepository) {
        this.userLocationRepository = userLocationRepository;
    }

    public List<UserLocation> getNearestUsers(int n) {
        Pageable pageable = PageRequest.of(0, n);  // Retrieve first n users
        return userLocationRepository.findAll(pageable).getContent();

    }


}