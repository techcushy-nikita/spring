package com.task.entity;

public enum UserRole {
    ADMIN,READER
}
